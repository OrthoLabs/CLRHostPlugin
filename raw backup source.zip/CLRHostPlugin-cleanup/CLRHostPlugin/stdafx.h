#pragma once

#include "OBSApi.h" //includes Windows.h

#include <metahost.h>
#include <algorithm>
#include <vector>
#include <string>
#include <map>